import { Router } from "express";

const router = Router();

/**
 * ==========================================
 * GEMINI REASONING LAYER (MOCK)
 * ==========================================
 * In a production environment, this function would call the Google Gemini API
 * using the provided security logs as context. It would use a specialized 
 * cybersecurity prompt to analyze patterns and intent.
 */
async function callGeminiReasoning(logData: string) {
  const isBruteForce = logData.toLowerCase().includes("failed") || 
                       logData.toLowerCase().includes("invalid") ||
                       logData.toLowerCase().includes("denied");

  if (isBruteForce) {
    return {
      threat_type: "Brute Force Attack (SSH)",
      risk_score: 85,
      reasoning: "Analysis of the raw log stream indicates a high-velocity authentication failure pattern. The source IP 192.168.1.105 is attempting to access the 'admin' account with multiple variations of credentials within seconds. This bypasses standard human typing speeds, confirming an automated dictionary or brute-force tool is in use.",
      storytelling: {
        why_dangerous: "Brute force attacks are the 'front door' for attackers. If successful, they gain full administrative control, allowing them to install ransomware or exfiltrate sensitive data.",
        if_ignored: "The attacker will eventually find a weak password or cause a Denial of Service (DoS) by locking out legitimate accounts.",
        mitigation: "Blocking the source IP provides immediate relief, but long-term safety requires Multi-Factor Authentication (MFA)."
      },
      recommendation: "Block source IP 192.168.1.105 immediately. Audit all successful logins from this IP in the last 24 hours.",
    };
  }

  return {
    threat_type: "Normal Activity",
    risk_score: 5,
    reasoning: "The log entry shows a successful session initialization following a standard authentication flow. No anomalous patterns or known malicious signatures were detected.",
    storytelling: {
      why_dangerous: "While this specific event is safe, routine access should always be monitored for 'Impossible Travel' or unusual login times.",
      if_ignored: "N/A - This is a baseline event.",
      mitigation: "Ensure logging remains enabled for future audit trails."
    },
    recommendation: "No action required. Continue routine monitoring.",
  };
}

/**
 * ==========================================
 * INCIDENT REPORT GENERATOR (LIGHTWEIGHT)
 * ==========================================
 * Generates a structured incident report based on the analysis.
 */
function generateIncidentReport(analysis: any, logData: string) {
  const timestamp = new Date().toISOString();
  const reportId = `CG-INC-${Math.floor(1000 + Math.random() * 9000)}`;

  return {
    report_metadata: {
      report_id: reportId,
      timestamp: timestamp,
      status: analysis.risk_score > 50 ? "CRITICAL" : "STABLE",
    },
    executive_summary: {
      overview: `CyberGuard AI identified ${analysis.threat_type} with a risk score of ${analysis.risk_score}/100.`,
      impact_level: analysis.risk_score > 70 ? "High - Potential System Compromise" : "Low - Routine Monitoring",
    },
    technical_details: {
      detected_threat: analysis.threat_type,
      raw_log_context: logData.substring(0, 200) + (logData.length > 200 ? "..." : ""),
      ai_reasoning: analysis.reasoning,
    },
    remediation_plan: {
      immediate_action: analysis.recommendation,
      long_term_strategy: analysis.storytelling.mitigation,
    }
  };
}

/**
 * DEMO ENDPOINT: POST /api/analyze
 */
router.post("/analyze", async (req, res) => {
  const { logData } = req.body;

  if (!logData) {
    return res.status(400).json({ error: "No log data provided" });
  }

  // STEP 1: Simulate AI Analysis (Mock Gemini)
  const analysis = await callGeminiReasoning(logData);

  // STEP 2: Generate Incident Report
  const report = generateIncidentReport(analysis, logData);

  // Return combined result for the UI
  return res.json({
    ...analysis,
    report: report
  });
});

export default router;
