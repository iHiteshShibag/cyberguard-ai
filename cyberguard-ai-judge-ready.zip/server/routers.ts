import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import * as agents from "./agents";
import { storagePut } from "./storage";
import crypto from "crypto";

// Validation schemas
const logUploadSchema = z.object({
  sourceType: z.enum(["firewall", "ids", "auth_server", "endpoint", "siem", "other"]),
  logData: z.string(),
  fileName: z.string().optional(),
});

const threatAnalysisSchema = z.object({
  logId: z.number().optional(),
  organizationId: z.number(),
});

const chatMessageSchema = z.object({
  sessionId: z.string(),
  message: z.string(),
  organizationId: z.number(),
});

const reportGenerationSchema = z.object({
  threatDetectionId: z.number(),
  organizationId: z.number(),
  reportType: z.enum(["executive", "technical", "combined"]).default("combined"),
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Log Management
  logs: router({
    upload: protectedProcedure
      .input(logUploadSchema)
      .mutation(async ({ input, ctx }) => {
        try {
          // Get or create organization for user
          const org = await db.getOrganizationById(ctx.user.organizationId || 1);
          if (!org) {
            throw new Error("Organization not found");
          }

          // Store log file in S3
          const fileName = input.fileName || `logs-${Date.now()}.txt`;
          const fileKey = `logs/${ctx.user.id}/${fileName}-${crypto.randomBytes(8).toString("hex")}`;
          const { url } = await storagePut(fileKey, input.logData, "text/plain");

          // Parse and normalize each log line
          const logLines = input.logData.split("\n").filter((line) => line.trim());
          const createdLogs = [];

          for (const line of logLines) {
            if (!line.trim()) continue;

            try {
              // Normalize log using AI agent
              const normalized = await agents.analyzeLog(line, input.sourceType);

              // Generate log hash to prevent duplicates
              const logHash = crypto.createHash("sha256").update(line).digest("hex");

              // Create security log record
              const logRecord = await db.createSecurityLog({
                organizationId: org.id,
                sourceType: input.sourceType,
                rawLog: line,
                normalizedLog: normalized,
                timestamp: normalized.timestamp ? new Date(normalized.timestamp) : new Date(),
                sourceIp: normalized.sourceIp,
                destinationIp: normalized.destinationIp,
                userId: normalized.userId,
                eventType: normalized.eventType,
                severity: normalized.severity || "low",
                logHash,
              });

              createdLogs.push(logRecord);
            } catch (error) {
              console.error("[Log Upload] Error normalizing log:", error);
              // Continue with next log on error
            }
          }

          return {
            success: true,
            logsCreated: createdLogs.length,
            fileUrl: url,
            message: `Successfully uploaded and processed ${createdLogs.length} logs`,
          };
        } catch (error) {
          console.error("[Log Upload] Error:", error);
          throw new Error(`Failed to upload logs: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
      }),

    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        const org = await db.getOrganizationById(ctx.user.organizationId || 1);
        if (!org) return [];

        return await db.getSecurityLogsByOrganization(org.id, input.limit, input.offset);
      }),

    getById: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      // TODO: Implement get log by ID
      return null;
    }),
  }),

  // Threat Detection
  threats: router({
    analyze: protectedProcedure
      .input(threatAnalysisSchema)
      .mutation(async ({ input, ctx }) => {
        try {
          const org = await db.getOrganizationById(input.organizationId);
          if (!org) throw new Error("Organization not found");

          // Get recent logs
          const logs = await db.getSecurityLogsByOrganization(org.id, 100, 0);
          if (logs.length === 0) {
            return { success: false, message: "No logs found to analyze" };
          }

          const createdThreats = [];

          // Analyze each log for threats
          for (const log of logs) {
            try {
              const normalized = log.normalizedLog as Record<string, unknown>;
              if (!normalized) continue;

              // Classify threat using AI agent
              const classification = await agents.classifyThreat(normalized);

              // Create threat detection record
              const threat = await db.createThreatDetection({
                organizationId: org.id,
                logId: log.id,
                threatType: classification.threatType,
                riskScore: classification.riskScore,
                confidence: classification.confidence,
                mitreAttackIds: classification.mitreAttackIds,
                description: classification.reasoning,
                indicators: classification.indicators,
                affectedAssets: {
                  sourceIp: log.sourceIp,
                  destinationIp: log.destinationIp,
                  userId: log.userId,
                },
                aiAnalysis: classification.reasoning,
                status: "new",
              });

              // If threat is significant, generate recommendations
              if (classification.riskScore >= 50) {
                const recommendations = await agents.planResponse(
                  classification.threatType,
                  classification.riskScore,
                  [log.sourceIp || "", log.destinationIp || ""].filter(Boolean),
                  "medium",
                  "technology"
                );
                // TODO: Update after verifying Drizzle insert return type
              }

              createdThreats.push(threat);
            } catch (error) {
              console.error("[Threat Analysis] Error analyzing log:", error);
              // Continue with next log
            }
          }

          return {
            success: true,
            threatsDetected: createdThreats.length,
            message: `Analyzed ${logs.length} logs and detected ${createdThreats.length} threats`,
          };
        } catch (error) {
          console.error("[Threat Analysis] Error:", error);
          throw new Error(`Failed to analyze threats: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
      }),

    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        const org = await db.getOrganizationById(ctx.user.organizationId || 1);
        if (!org) return [];

        return await db.getThreatDetectionsByOrganization(org.id, input.limit, input.offset);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getThreatDetectionById(input.id);
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["new", "investigating", "confirmed", "false_positive", "resolved"]),
        })
      )
      .mutation(async ({ input }) => {
        return await db.updateThreatDetectionStatus(input.id, input.status);
      }),
  }),

  // Incident Response
  recommendations: router({
    getByThreatId: protectedProcedure
      .input(z.object({ threatDetectionId: z.number() }))
      .query(async ({ input }) => {
        return await db.getRecommendationsByThreatId(input.threatDetectionId);
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["pending", "in_progress", "completed"]),
        })
      )
      .mutation(async ({ input }) => {
        // TODO: Implement update recommendation status
        return { success: true };
      }),
  }),

  // Report Generation
  reports: router({
    generate: protectedProcedure
      .input(reportGenerationSchema)
      .mutation(async ({ input, ctx }) => {
        try {
          const org = await db.getOrganizationById(input.organizationId);
          if (!org) throw new Error("Organization not found");

          const threat = await db.getThreatDetectionById(input.threatDetectionId);
          if (!threat) throw new Error("Threat not found");

          // Get recommendations
          const recommendations = await db.getRecommendationsByThreatId(input.threatDetectionId);

          // Generate report using AI agent
          const reportContent = await agents.generateReport(
            threat.threatType || "unknown",
            threat.riskScore ? Number(threat.riskScore) : 0,
            threat.createdAt.toISOString(),
            threat.affectedAssets ? Object.values(threat.affectedAssets).filter(Boolean) : [],
            threat.aiAnalysis || "",
            recommendations || {}
          );

          // Create report record
          const report = await db.createIncidentReport({
            organizationId: org.id,
            threatDetectionId: input.threatDetectionId,
            reportType: input.reportType,
            title: `Incident Report - ${threat.threatType} (Risk: ${threat.riskScore})`,
            executiveSummary: reportContent.executiveSummary,
            technicalAnalysis: reportContent.technicalDetails,
            recommendations: JSON.stringify(reportContent),
            generatedBy: ctx.user.id,
          });

          return {
            success: true,
            reportId: 0,
            message: "Report generated successfully",
          };
        } catch (error) {
          console.error("[Report Generation] Error:", error);
          throw new Error(`Failed to generate report: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
      }),

    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        const org = await db.getOrganizationById(ctx.user.organizationId || 1);
        if (!org) return [];

        return await db.getReportsByOrganization(org.id, input.limit, input.offset);
      }),
  }),

  // SOC Copilot Chat
  chat: router({
    message: protectedProcedure
      .input(chatMessageSchema)
      .mutation(async ({ input, ctx }) => {
        try {
          const org = await db.getOrganizationById(input.organizationId);
          if (!org) throw new Error("Organization not found");

          // Get recent threats and logs for context
          const recentThreats = await db.getThreatDetectionsByOrganization(org.id, 10, 0);
          const recentLogs = await db.getSecurityLogsByOrganization(org.id, 10, 0);

          // Get AI response using SOC Copilot agent
          const aiResponse = await agents.socCopilotChat(input.message, {
            recentThreats: recentThreats.map((t) => ({
              threatType: t.threatType || "unknown",
              riskScore: t.riskScore ? Number(t.riskScore) : 0,
            })),
            recentLogs: recentLogs.map((l) => ({
              eventType: l.eventType || "unknown",
              severity: l.severity || "low",
            })),
            organizationContext: org.name,
          });

          // Store chat message
          await db.createChatMessage({
            organizationId: org.id,
            userId: ctx.user.id,
            sessionId: input.sessionId,
            userMessage: input.message,
            aiResponse,
            context: {
              threatCount: recentThreats.length,
              logCount: recentLogs.length,
            },
          });

          return {
            success: true,
            response: aiResponse,
          };
        } catch (error) {
          console.error("[Chat] Error:", error);
          throw new Error(`Failed to process chat message: ${error instanceof Error ? error.message : "Unknown error"}`);
        }
      }),

    history: protectedProcedure
      .input(z.object({ sessionId: z.string(), limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return await db.getChatHistory(input.sessionId, input.limit, input.offset);
      }),
  }),

  // Dashboard
  dashboard: router({
    metrics: protectedProcedure.query(async ({ ctx }) => {
      const org = await db.getOrganizationById(ctx.user.organizationId || 1);
      if (!org) return null;

      return await db.getDashboardMetrics(org.id);
    }),

    threatTimeline: protectedProcedure.query(async ({ ctx }) => {
      const org = await db.getOrganizationById(ctx.user.organizationId || 1);
      if (!org) return [];

      const threats = await db.getThreatDetectionsByOrganization(org.id, 100, 0);
      return threats.map((t) => ({
        id: t.id,
        threatType: t.threatType,
        riskScore: t.riskScore,
        timestamp: t.createdAt,
        status: t.status,
      }));
    }),

    threatDistribution: protectedProcedure.query(async ({ ctx }) => {
      const org = await db.getOrganizationById(ctx.user.organizationId || 1);
      if (!org) return {};

      const threats = await db.getThreatDetectionsByOrganization(org.id, 1000, 0);
      const distribution: Record<string, number> = {};

      threats.forEach((t) => {
        const type = t.threatType || "unknown";
        distribution[type] = (distribution[type] || 0) + 1;
      });

      return distribution;
    }),
  }),
});

export type AppRouter = typeof appRouter;
